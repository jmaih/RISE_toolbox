%%%%%%%%%%%%%%%%%%%%   path: m\optimizers\private   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help m\optimizers\private\check_convergence">m\optimizers\private\check_convergence</a>   - if rem(obj.iter,100)==0 || ~isempty(stopflag)
%   <a href="matlab:help m\optimizers\private\clear_duplicates">m\optimizers\private\clear_duplicates</a>    - % select the chromosomes to change randomly
%   m\optimizers\private\compute_fitness     - (No help available)
%   m\optimizers\private\dispersion          - (No help available)
%   <a href="matlab:help m\optimizers\private\display_progress">m\optimizers\private\display_progress</a>    - fprintf(1,'restart # %3.0f   iter: %6.0f   fmin(global) %8.4f    fmin(iter) %8.4f    dispersion %8.4f    fcount  %8.0f   routine %s\n',...
%   m\optimizers\private\distance            - (No help available)
%   m\optimizers\private\find_farthest       - (No help available)
%   m\optimizers\private\find_nearest        - (No help available)
%   <a href="matlab:help m\optimizers\private\generate_candidates">m\optimizers\private\generate_candidates</a> -  we get 4 outputs?
%   <a href="matlab:help m\optimizers\private\manual_stopping">m\optimizers\private\manual_stopping</a>     - rawfile = char(textread(ManualStoppingFile,'%s','delimiter','\n','whitespace','','bufsize',40000));
%   m\optimizers\private\recenter            - (No help available)
%   <a href="matlab:help m\optimizers\private\uniform_sampling">m\optimizers\private\uniform_sampling</a>    - samples without repetition
%   <a href="matlab:help m\optimizers\private\weighted_sampling">m\optimizers\private\weighted_sampling</a>   - samples without repetition
