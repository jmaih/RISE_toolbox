%%%%%%%%%%%%%%%%%%%%   path: m\hessian_computation   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help m\hessian_computation\finite_difference_hessian">m\hessian_computation\finite_difference_hessian</a> - Compute the stepsize (h)
%   <a href="matlab:help m\hessian_computation\hessian_computation_test">m\hessian_computation\hessian_computation_test</a>  - load some data
%   <a href="matlab:help m\hessian_computation\hessian_conditioner">m\hessian_computation\hessian_conditioner</a>       - based on ddom.m
%   <a href="matlab:help m\hessian_computation\outer_product_hessian">m\hessian_computation\outer_product_hessian</a>     - Objective is assumed to have at least two output arguments
