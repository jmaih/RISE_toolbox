function out = if_then_else(cond,opt1,opt2)

if cond
    out=opt1;
else
    out=opt2;
end
                                                               
end

