%%%%%%%%%%%%%%%%%%%%   path: m\parsers   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help m\parsers\CompileModelFile">m\parsers\CompileModelFile</a>          - by the way, I can still declare exogenous and make them observable at the
%   <a href="matlab:help m\parsers\analytical_symbolic_form">m\parsers\analytical_symbolic_form</a>  - turns x(1),y(1),ss(1),p(1) into x_1,y_1,ss_1,p_1
%   <a href="matlab:help m\parsers\cellstr2mat">m\parsers\cellstr2mat</a>               - unction out=cellstr2mat(CellMat) %,MatName
%   <a href="matlab:help m\parsers\chain_grid">m\parsers\chain_grid</a>                - v is a vector of the number of states in each markov chain
%   m\parsers\is_transition_probability - (No help available)
%   <a href="matlab:help m\parsers\symbolic2model">m\parsers\symbolic2model</a>            - shad=[shad,eqtn]; %#ok<*AGROW>
%   <a href="matlab:help m\parsers\update_markov_chains_info">m\parsers\update_markov_chains_info</a> - creates a markov chain info and updates it as new information comes in.
