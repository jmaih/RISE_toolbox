%%%%%%%%%%%%%%%%%%%%   path: examples\MomentsToBounds   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\MomentsToBounds\howto">examples\MomentsToBounds\howto</a> - % computing the bounds from the mean and standard deviations from dynare
