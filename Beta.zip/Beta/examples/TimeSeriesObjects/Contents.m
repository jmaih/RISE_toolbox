%%%%%%%%%%%%%%%%%%%%   path: examples\TimeSeriesObjects   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\TimeSeriesObjects\howto">examples\TimeSeriesObjects\howto</a> - % create empty time series
