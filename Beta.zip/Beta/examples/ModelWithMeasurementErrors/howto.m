%% housekeeping
close all
clear
clc
%% add the necessary paths
setpaths

%% there is nothing complicated about measurement errors.

% they are easily calibrated or estimated. Just look at the model file
