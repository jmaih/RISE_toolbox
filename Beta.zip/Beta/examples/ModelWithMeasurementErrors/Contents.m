%%%%%%%%%%%%%%%%%%%%   path: examples\ModelWithMeasurementErrors   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\ModelWithMeasurementErrors\howto">examples\ModelWithMeasurementErrors\howto</a> - % housekeeping
