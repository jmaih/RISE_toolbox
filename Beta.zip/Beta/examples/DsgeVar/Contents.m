%%%%%%%%%%%%%%%%%%%%   path: examples\DsgeVar   %%%%%%%%%%%%%%%%%%%%
%
%   examples\DsgeVar\datarabanal_hybrid - (No help available)
%   <a href="matlab:help examples\DsgeVar\howto">examples\DsgeVar\howto</a>              - % housekeeping
