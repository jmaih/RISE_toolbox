%%%%%%%%%%%%%%%%%%%%   path: examples\LagsOnExogenousProcesses   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\LagsOnExogenousProcesses\howto">examples\LagsOnExogenousProcesses\howto</a> - % housekeeping
