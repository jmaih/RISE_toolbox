%%%%%%%%%%%%%%%%%%%%   path: examples\BoundsToMoments   %%%%%%%%%%%%%%%%%%%%
%
%   examples\BoundsToMoments\howto - (No help available)
