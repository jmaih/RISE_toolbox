%%%%%%%%%%%%%%%%%%%%   path: examples\OptimalSimpleRules   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\OptimalSimpleRules\howto">examples\OptimalSimpleRules\howto</a> - % housekeeping
