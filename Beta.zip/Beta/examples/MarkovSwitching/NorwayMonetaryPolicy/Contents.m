%%%%%%%%%%%%%%%%%%%%   path: examples\MarkovSwitching\NorwayMonetaryPolicy   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\MarkovSwitching\NorwayMonetaryPolicy\RegimeSwitchesNorway">examples\MarkovSwitching\NorwayMonetaryPolicy\RegimeSwitchesNorway</a>           - % housekeeping
%   <a href="matlab:help examples\MarkovSwitching\NorwayMonetaryPolicy\howto_forecast">examples\MarkovSwitching\NorwayMonetaryPolicy\howto_forecast</a>                 - % introduction
%   <a href="matlab:help examples\MarkovSwitching\NorwayMonetaryPolicy\manhattan_beach">examples\MarkovSwitching\NorwayMonetaryPolicy\manhattan_beach</a>                - % housekeeping
%   <a href="matlab:help examples\MarkovSwitching\NorwayMonetaryPolicy\max_operator_behavior_test">examples\MarkovSwitching\NorwayMonetaryPolicy\max_operator_behavior_test</a>     - this function checks that expected monetary policy shocks are positive
%   <a href="matlab:help examples\MarkovSwitching\NorwayMonetaryPolicy\steady_state_4_Canonical_Const">examples\MarkovSwitching\NorwayMonetaryPolicy\steady_state_4_Canonical_Const</a> - unction [ss,var_names,retcode]=steady_state_4_Canonical_Const(param_obj)%param_struct=struct(parlist,parvals)
