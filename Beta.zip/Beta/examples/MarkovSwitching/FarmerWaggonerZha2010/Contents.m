%%%%%%%%%%%%%%%%%%%%   path: examples\MarkovSwitching\FarmerWaggonerZha2010   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\MarkovSwitching\FarmerWaggonerZha2010\fwz_test_suite_dynare_conf">examples\MarkovSwitching\FarmerWaggonerZha2010\fwz_test_suite_dynare_conf</a>                              - % housekeeping
%   examples\MarkovSwitching\FarmerWaggonerZha2010\generate_markov_switching_rational_expectations_problem - (No help available)
%   <a href="matlab:help examples\MarkovSwitching\FarmerWaggonerZha2010\howto">examples\MarkovSwitching\FarmerWaggonerZha2010\howto</a>                                                   - % housekeeping
