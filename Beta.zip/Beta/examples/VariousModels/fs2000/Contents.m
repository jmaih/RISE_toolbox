%%%%%%%%%%%%%%%%%%%%   path: examples\VariousModels\fs2000   %%%%%%%%%%%%%%%%%%%%
%
%   examples\VariousModels\fs2000\csminwellwrap - (No help available)
%   <a href="matlab:help examples\VariousModels\fs2000\howto">examples\VariousModels\fs2000\howto</a>         - % housekeeping
