%%%%%%%%%%%%%%%%%%%%   path: examples\VariousModels\SmetsWouters   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\VariousModels\SmetsWouters\howto">examples\VariousModels\SmetsWouters\howto</a>               - % housekeeping
%   <a href="matlab:help examples\VariousModels\SmetsWouters\usmodel_steadystate">examples\VariousModels\SmetsWouters\usmodel_steadystate</a> - computes the steady state for the observed variables in the smets-wouters
