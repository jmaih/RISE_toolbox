%%%%%%%%%%%%%%%%%%%%   path: examples\VariousModels\PeterIreland\technology_shocks   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\VariousModels\PeterIreland\technology_shocks\howto">examples\VariousModels\PeterIreland\technology_shocks\howto</a> - % housekeeping
