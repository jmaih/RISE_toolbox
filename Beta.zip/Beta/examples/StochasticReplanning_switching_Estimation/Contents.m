%%%%%%%%%%%%%%%%%%%%   path: examples\StochasticReplanning_switching_Estimation   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\StochasticReplanning_switching_Estimation\howto">examples\StochasticReplanning_switching_Estimation\howto</a>               - % housekeeping
%   <a href="matlab:help examples\StochasticReplanning_switching_Estimation\usmodel_steadystate">examples\StochasticReplanning_switching_Estimation\usmodel_steadystate</a> - computes the steady state for the observed variables in the smets-wouters
