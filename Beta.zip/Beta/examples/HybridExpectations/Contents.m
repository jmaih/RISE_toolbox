%%%%%%%%%%%%%%%%%%%%   path: examples\HybridExpectations   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\HybridExpectations\howto">examples\HybridExpectations\howto</a> - % housekeeping
