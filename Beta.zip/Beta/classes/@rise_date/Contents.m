%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_date   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_date\rise_date">classes\@rise_date\rise_date</a> - % TODO:
