%%%%%%%%%%%%%%%%%%%%   path: classes\+ols   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+ols\ordinary_least_squares">classes\+ols\ordinary_least_squares</a> - ig2=RSS/T; % maximum likelihood estimator
