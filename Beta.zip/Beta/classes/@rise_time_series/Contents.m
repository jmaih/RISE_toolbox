%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_time_series   %%%%%%%%%%%%%%%%%%%%
%
%   classes\@rise_time_series\aggregate                 - (No help available)
%   <a href="matlab:help classes\@rise_time_series\automatic_model_selection">classes\@rise_time_series\automatic_model_selection</a> - unction FinalResults=automatic_model_selection(obj,endo_name,exo_names,options)%[final_mod,x]
%   <a href="matlab:help classes\@rise_time_series\line">classes\@rise_time_series\line</a>                      - 10             'yyyy'                   2000
%   classes\@rise_time_series\mpower                    - (No help available)
%   <a href="matlab:help classes\@rise_time_series\plot">classes\@rise_time_series\plot</a>                      - 10             'yyyy'                   2000
%   <a href="matlab:help classes\@rise_time_series\plot_separate">classes\@rise_time_series\plot_separate</a>             - obj=this.subsref(S); % <--- obj=this(vnames{id}); does not work
%   <a href="matlab:help classes\@rise_time_series\rise_time_series">classes\@rise_time_series\rise_time_series</a>          - for kk=1:numel(s)
