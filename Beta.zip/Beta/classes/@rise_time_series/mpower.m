function this=mpower(this,const)
this=exp(const*log(this));
end
