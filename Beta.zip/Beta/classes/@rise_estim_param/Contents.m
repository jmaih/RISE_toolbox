%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_estim_param   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_estim_param\plot">classes\@rise_estim_param\plot</a>             - % functions of the distribution
%   <a href="matlab:help classes\@rise_estim_param\rise_estim_param">classes\@rise_estim_param\rise_estim_param</a> - % %         function_log_pdf
%   classes\@rise_estim_param\set_properties   - (No help available)
