%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_endo_priors   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_endo_priors\rise_endo_priors">classes\@rise_endo_priors\rise_endo_priors</a> - Shat % zero-frequency spectral density
