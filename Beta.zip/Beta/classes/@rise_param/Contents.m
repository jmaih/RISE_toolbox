%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_param   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_param\rise_param">classes\@rise_param\rise_param</a>     - % set property utility
%   classes\@rise_param\set_properties - (No help available)
