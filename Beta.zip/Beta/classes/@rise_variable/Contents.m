%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_variable   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_variable\rise_variable">classes\@rise_variable\rise_variable</a> - % value moved under protection because it is necessary to pass it
