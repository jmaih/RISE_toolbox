%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_anonymous   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_anonymous\rise_anonymous">classes\@rise_anonymous\rise_anonymous</a> - val_i=eval(obj(ii),varargin{:}); %#ok<*EVLC>
