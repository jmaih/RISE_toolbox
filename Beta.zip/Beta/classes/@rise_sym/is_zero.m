function flag=is_zero(a)
flag=is_zero(a.func);
end

