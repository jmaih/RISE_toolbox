function close_differentiation_session()
clear persistent rise_sym_main_map
end