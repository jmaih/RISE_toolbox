function flag=is_one(a)
flag=is_one(a.func);
end
