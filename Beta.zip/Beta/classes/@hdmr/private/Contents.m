%%%%%%%%%%%%%%%%%%%%   path: classes\@hdmr\private   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@hdmr\private\orthonormal_polynomial">classes\@hdmr\private\orthonormal_polynomial</a>     - arning('off')%#ok<WNOFF> %,'MATLAB:divideByZero'
%   <a href="matlab:help classes\@hdmr\private\orthonormal_polynomial_old">classes\@hdmr\private\orthonormal_polynomial_old</a> - ==================
%   <a href="matlab:help classes\@hdmr\private\theta_to_x">classes\@hdmr\private\theta_to_x</a>                 - normalize
