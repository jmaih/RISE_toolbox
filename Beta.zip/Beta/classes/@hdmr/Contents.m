%%%%%%%%%%%%%%%%%%%%   path: classes\@hdmr   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@hdmr\hdmr">classes\@hdmr\hdmr</a> - % objective is either : f and theta or a function that will help
