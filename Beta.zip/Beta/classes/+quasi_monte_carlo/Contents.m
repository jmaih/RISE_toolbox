%%%%%%%%%%%%%%%%%%%%   path: classes\+quasi_monte_carlo   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+quasi_monte_carlo\halton">classes\+quasi_monte_carlo\halton</a>          - Examples:
%   classes\+quasi_monte_carlo\latin_hypercube - (No help available)
%   <a href="matlab:help classes\+quasi_monte_carlo\sobol">classes\+quasi_monte_carlo\sobol</a>           - Examples:
