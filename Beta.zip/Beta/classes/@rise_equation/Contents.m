%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_equation   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_equation\rise_equation">classes\@rise_equation\rise_equation</a> - % set property utility
