%%%%%%%%%%%%%%%%%%%%   path: m\forecasting   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help m\forecasting\forecast_engine">m\forecasting\forecast_engine</a>              - Description:
%   <a href="matlab:help m\forecasting\forecasting_engine">m\forecasting\forecasting_engine</a>           - Description:
%   <a href="matlab:help m\forecasting\three_pass_regression_filter">m\forecasting\three_pass_regression_filter</a> - inputs:
