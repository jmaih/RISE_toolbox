%%%%%%%%%%%%%%%%%%%%   path: m\differentiation   %%%%%%%%%%%%%%%%%%%%
%
%   m\differentiation\rise_numjac - (No help available)
