%%%%%%%%%%%%%%%%%%%%   path: m\filtering\+junk   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help m\filtering\+junk\CheckPositiveDefiniteness">m\filtering\+junk\CheckPositiveDefiniteness</a>                - iF=F\eye(size(F,1));%inv(F);
%   <a href="matlab:help m\filtering\+junk\kalman_prediction">m\filtering\+junk\kalman_prediction</a>                        - only compute the places where there is some action
%   <a href="matlab:help m\filtering\+junk\kalman_update">m\filtering\+junk\kalman_update</a>                            - K=P(:,obs_id);
%   <a href="matlab:help m\filtering\+junk\markov_switching_kalman_filter">m\filtering\+junk\markov_switching_kalman_filter</a>           - Detailed explanation to come here
%   <a href="matlab:help m\filtering\+junk\markov_switching_kalman_filter_real_time">m\filtering\+junk\markov_switching_kalman_filter_real_time</a> - y,... % data
%   <a href="matlab:help m\filtering\+junk\smoothing_step">m\filtering\+junk\smoothing_step</a>                           - Note that Durbin and Koopman define K=T*P*Z'*iF, while here it is defined
%   <a href="matlab:help m\filtering\+junk\symmetrize">m\filtering\+junk\symmetrize</a>                               - unction B=symmetrize(A)%,flag
%   <a href="matlab:help m\filtering\+junk\update_and_collapse">m\filtering\+junk\update_and_collapse</a>                      - Ptt(:,:,snow)=Ptt(:,:,snow)/PAItt(snow); %symmetrize()
