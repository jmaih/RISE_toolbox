%%%%%%%%%%%%%%%%%%%%   path: m\filtering   %%%%%%%%%%%%%%%%%%%%
%
%   m\filtering\conditional_likelihood           - (No help available)
%   m\filtering\initial_markov_distribution      - (No help available)
%   <a href="matlab:help m\filtering\kalman_initialization">m\filtering\kalman_initialization</a>            - There is no documentation of this function yet.
%   <a href="matlab:help m\filtering\likelihood_dsge_var">m\filtering\likelihood_dsge_var</a>              - N.B: This function assumes the likelihood is to be maximized
%   <a href="matlab:help m\filtering\likelihood_markov_switching_dsge">m\filtering\likelihood_markov_switching_dsge</a> - unction [LogLik,Incr,retcode,obj]=likelihood_markov_switching_dsge(params,obj)%
%   <a href="matlab:help m\filtering\likelihood_optimal_simple_rule">m\filtering\likelihood_optimal_simple_rule</a>   - % this important output is not created yet
%   <a href="matlab:help m\filtering\msre_kalman_cell">m\filtering\msre_kalman_cell</a>                 - this filter assumes a state space of the form
%   <a href="matlab:help m\filtering\msre_linear_filter">m\filtering\msre_linear_filter</a>               - all rows of Q should sum to 1
