%%%%%%%%%%%%%%%%%%%%   path: examples\VariousModels\KaijiTutorial   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\VariousModels\KaijiTutorial\howto">examples\VariousModels\KaijiTutorial\howto</a>     - % housekeeping
%   <a href="matlab:help examples\VariousModels\KaijiTutorial\howto_exp">examples\VariousModels\KaijiTutorial\howto_exp</a> - % housekeeping
