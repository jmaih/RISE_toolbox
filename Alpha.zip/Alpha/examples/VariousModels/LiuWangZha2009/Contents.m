%%%%%%%%%%%%%%%%%%%%   path: examples\VariousModels\LiuWangZha2009   %%%%%%%%%%%%%%%%%%%%
%
%   examples\VariousModels\LiuWangZha2009\data_diff_FHFA - (No help available)
%   <a href="matlab:help examples\VariousModels\LiuWangZha2009\howto">examples\VariousModels\LiuWangZha2009\howto</a>          - % housekeeping
