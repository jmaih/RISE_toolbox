%% housekeeping
close all
clear
clc
%% add the necessary paths
setpaths

%% It just amounts to adding a keyword in the parameter list

he=rise('hybrid_expect');

he=he.solve;


