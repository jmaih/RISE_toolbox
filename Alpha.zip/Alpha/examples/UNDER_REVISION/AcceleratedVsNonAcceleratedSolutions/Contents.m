%%%%%%%%%%%%%%%%%%%%   path: examples\AcceleratedVsNonAcceleratedSolutions   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\AcceleratedVsNonAcceleratedSolutions\howto">examples\AcceleratedVsNonAcceleratedSolutions\howto</a>    - % housekeeping
%   <a href="matlab:help examples\AcceleratedVsNonAcceleratedSolutions\howto_sw">examples\AcceleratedVsNonAcceleratedSolutions\howto_sw</a> - % housekeeping
