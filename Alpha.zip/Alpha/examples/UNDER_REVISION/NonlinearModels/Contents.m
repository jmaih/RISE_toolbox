%%%%%%%%%%%%%%%%%%%%   path: examples\NonlinearModels   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\NonlinearModels\fs2000_steadystate">examples\NonlinearModels\fs2000_steadystate</a>         - computes the steady state of fs2000 analyticaly
%   <a href="matlab:help examples\NonlinearModels\fs2000_steadystate_initval">examples\NonlinearModels\fs2000_steadystate_initval</a> - gives approximate values for the steady state of fs2000
%   <a href="matlab:help examples\NonlinearModels\howto">examples\NonlinearModels\howto</a>                      - % housekeeping
