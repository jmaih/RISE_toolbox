%%%%%%%%%%%%%%%%%%%%   path: examples\SymbolicDifferentiation   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\SymbolicDifferentiation\test_symbolic">examples\SymbolicDifferentiation\test_symbolic</a>   - % housekeeping
%   <a href="matlab:help examples\SymbolicDifferentiation\test_symbolic_2">examples\SymbolicDifferentiation\test_symbolic_2</a> - % create function
