%%%%%%%%%%%%%%%%%%%%   path: examples\Linear_vs_Loglinear   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\Linear_vs_Loglinear\howto">examples\Linear_vs_Loglinear\howto</a>                           - % housekeeping
%   <a href="matlab:help examples\Linear_vs_Loglinear\tshocksnk_steadystate">examples\Linear_vs_Loglinear\tshocksnk_steadystate</a>           - params=vertcat(param_obj.startval); %#ok<NASGU>
%   <a href="matlab:help examples\Linear_vs_Loglinear\tshocksnk_steadystate_loglinear">examples\Linear_vs_Loglinear\tshocksnk_steadystate_loglinear</a> - params=vertcat(param_obj.startval); %#ok<NASGU>
