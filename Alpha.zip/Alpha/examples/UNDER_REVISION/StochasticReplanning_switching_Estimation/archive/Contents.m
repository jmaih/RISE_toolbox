%%%%%%%%%%%%%%%%%%%%   path: examples\StochasticReplanning_switching_Estimation\archive   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\StochasticReplanning_switching_Estimation\archive\usmodel_steadystate">examples\StochasticReplanning_switching_Estimation\archive\usmodel_steadystate</a> - computes the steady state for the observed variables in the smets-wouters
