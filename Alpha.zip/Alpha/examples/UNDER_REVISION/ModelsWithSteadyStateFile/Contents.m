%%%%%%%%%%%%%%%%%%%%   path: examples\ModelsWithSteadyStateFile   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\ModelsWithSteadyStateFile\howto">examples\ModelsWithSteadyStateFile\howto</a>                          - % housekeeping
%   <a href="matlab:help examples\ModelsWithSteadyStateFile\steady_state_4_Canonical_Const">examples\ModelsWithSteadyStateFile\steady_state_4_Canonical_Const</a> - unction [ss,param_obj,retcode,imposed]=steady_state_4_Canonical_Const(param_obj,flag)%param_struct=struct(parlist,parvals)
