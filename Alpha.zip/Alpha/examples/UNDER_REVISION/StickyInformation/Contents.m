%%%%%%%%%%%%%%%%%%%%   path: examples\StickyInformation   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\StickyInformation\howto">examples\StickyInformation\howto</a> - % housekeeping
