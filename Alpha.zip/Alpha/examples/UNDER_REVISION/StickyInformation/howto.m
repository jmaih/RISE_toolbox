%% housekeeping
close all
clear
clc
%% add the necessary paths
setpaths

%% It just amounts to adding a keyword in the parameter list

si=rise('sticky_info');

si=si.solve;


