%%%%%%%%%%%%%%%%%%%%   path: examples\HighDimensionalModelRepresentation   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\HighDimensionalModelRepresentation\howto">examples\HighDimensionalModelRepresentation\howto</a>                  - % housekeeping
%   <a href="matlab:help examples\HighDimensionalModelRepresentation\ishigami">examples\HighDimensionalModelRepresentation\ishigami</a>               - %%========================================
%   <a href="matlab:help examples\HighDimensionalModelRepresentation\polynomial_integration">examples\HighDimensionalModelRepresentation\polynomial_integration</a> -  is of the form a0+a1*x+...+ar*x^r
%   examples\HighDimensionalModelRepresentation\satelli_sobol95        - (No help available)
