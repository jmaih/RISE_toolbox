%%%%%%%%%%%%%%%%%%%%   path: examples\MonteCarloFiltering   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\MonteCarloFiltering\howto">examples\MonteCarloFiltering\howto</a>        - % housekeeping
%   <a href="matlab:help examples\MonteCarloFiltering\price_puzzle">examples\MonteCarloFiltering\price_puzzle</a> - % inflation
