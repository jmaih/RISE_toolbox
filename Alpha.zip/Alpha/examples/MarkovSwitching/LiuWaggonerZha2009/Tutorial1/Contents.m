%%%%%%%%%%%%%%%%%%%%   path: examples\MarkovSwitching\LiuWaggonerZha2009\Tutorial1   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\MarkovSwitching\LiuWaggonerZha2009\Tutorial1\howto">examples\MarkovSwitching\LiuWaggonerZha2009\Tutorial1\howto</a> - % housekeeping
