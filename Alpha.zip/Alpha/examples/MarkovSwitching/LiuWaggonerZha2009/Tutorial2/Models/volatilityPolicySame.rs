
%3) Markov-switching volatility and policy coefficients with the same process;
@#include "fwz_est.rs"
% volatility is controlled by markov chain vol.
@#include "switching_volatility.rs"
% Now we also add the policy parameters letting them be controlled by the same process
@#include "switching_policy_parameters_volChain.rs"

