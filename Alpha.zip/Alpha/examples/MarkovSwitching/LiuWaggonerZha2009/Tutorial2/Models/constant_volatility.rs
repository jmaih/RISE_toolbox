parameters sigd, "$\sigma _{d}$" sigs, "$\sigma _{s}$"	sigr, "$\sigma _{r}$"

parameterization
	sigd          ,    0.18   ,    0.0005,    1.0000,  weibull_pdf(.90);
	sigs          ,    0.3712 ,    0.0005,    1.0000,  weibull_pdf(.90);
	sigr          ,    0.18   ,    0.0005,    1.0000,  weibull_pdf(.90);
