%2) Markov-switching policy coefficients only;
@#include "fwz_est.rs"
@#include "switching_policy_parameters_coefChain.rs"
@#include "constant_volatility.rs"
