%1) Markov-switching volatilityonly;
@#include "fwz_est.rs"
@#include "constant_policy_parameters.rs"
@#include "switching_volatility.rs"

