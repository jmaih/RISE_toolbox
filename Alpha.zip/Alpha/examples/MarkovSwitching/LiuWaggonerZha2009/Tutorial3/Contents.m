%%%%%%%%%%%%%%%%%%%%   path: examples\MarkovSwitching\LiuWaggonerZha2009\Tutorial3   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\MarkovSwitching\LiuWaggonerZha2009\Tutorial3\howto">examples\MarkovSwitching\LiuWaggonerZha2009\Tutorial3\howto</a> - %
