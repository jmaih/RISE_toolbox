@#include "svar_core.rs"

@#include "switching_volatility.rs"

@#include "constant_policy.rs"