function DEL = delimiters()
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

DEL=[char([9:13,32]),'[]{}(),;=+-*/^@><'];

end

