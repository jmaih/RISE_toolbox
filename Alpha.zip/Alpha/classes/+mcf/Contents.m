%%%%%%%%%%%%%%%%%%%%   path: classes\+mcf   %%%%%%%%%%%%%%%%%%%%
%
%   classes\+mcf\plot_correlation_patterns - (No help available)
%   <a href="matlab:help classes\+mcf\plot_correlation_scatter">classes\+mcf\plot_correlation_scatter</a>  - npar=numel(parameter_names);
%   <a href="matlab:help classes\+mcf\plot_smirnov">classes\+mcf\plot_smirnov</a>              - % density plots
