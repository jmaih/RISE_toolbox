%%%%%%%%%%%%%%%%%%%%   path: classes\log_marginal_data_density   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\log_marginal_data_density\chib_jeliazkov">classes\log_marginal_data_density\chib_jeliazkov</a>         - % now sample J parameter vectors from the proposal density. I don't think I
%   classes\log_marginal_data_density\modified_harmonic_mean - (No help available)
