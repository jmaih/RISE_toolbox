function this3=times(this1,this2)
this3=mtimes(this1,this2);
end
