%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_time_series\private   %%%%%%%%%%%%%%%%%%%%
%
%   classes\@rise_time_series\private\CombineDates - (No help available)
