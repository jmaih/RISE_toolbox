function this3=rdivide(this1,this2)
% just to make division robust
this3=mrdivide(this1,this2);
end
