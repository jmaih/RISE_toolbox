function ts=nan(start_date,varargin)

data=nan(varargin{:});

ts=rise_time_series(start_date,data);

