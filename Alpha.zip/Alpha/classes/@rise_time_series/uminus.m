function this=uminus(this)
this=rise_time_series(this.start,-double(this),this.varnames);
end
