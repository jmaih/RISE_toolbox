%%%%%%%%%%%%%%%%%%%%   path: classes\+rise_moments   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+rise_moments\recursive_moments">classes\+rise_moments\recursive_moments</a> - {
