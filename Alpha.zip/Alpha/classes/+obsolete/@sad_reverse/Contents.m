%%%%%%%%%%%%%%%%%%%%   path: classes\@sad_reverse   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@sad_reverse\hessian">classes\@sad_reverse\hessian</a>     - call the jacobian in non-vectorized form
%   <a href="matlab:help classes\@sad_reverse\jacobian">classes\@sad_reverse\jacobian</a>    - %
%   <a href="matlab:help classes\@sad_reverse\sad_reverse">classes\@sad_reverse\sad_reverse</a> - %------------------
