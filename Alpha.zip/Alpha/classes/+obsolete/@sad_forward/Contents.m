%%%%%%%%%%%%%%%%%%%%   path: classes\@sad_forward   %%%%%%%%%%%%%%%%%%%%
%
%   classes\@sad_forward\hessian     - (No help available)
%   <a href="matlab:help classes\@sad_forward\jacobian">classes\@sad_forward\jacobian</a>    - objectives is a function handle or an array of function handles
%   <a href="matlab:help classes\@sad_forward\sad_forward">classes\@sad_forward\sad_forward</a> - lassdef sad_forward %< handle
