%%%%%%%%%%%%%%%%%%%%   path: classes\+obsolete   %%%%%%%%%%%%%%%%%%%%
%
%   classes\+obsolete\penalty_function - (No help available)
