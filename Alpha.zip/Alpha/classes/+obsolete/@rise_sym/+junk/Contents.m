%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_sym\+junk   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_sym\+junk\compact_form">classes\@rise_sym\+junk\compact_form</a> - % handle will push this information automatically.
