function initialize_differentiation_session(wrt)
rise_sym.push('initialize',wrt);
end
