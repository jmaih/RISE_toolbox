function flag=isnumeric(a)
flag=isnumeric(a.func);
end