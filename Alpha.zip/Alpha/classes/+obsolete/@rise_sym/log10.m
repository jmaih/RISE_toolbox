function obj=log10(a)
obj=log(a)/log(10);