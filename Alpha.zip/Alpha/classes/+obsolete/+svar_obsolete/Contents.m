%%%%%%%%%%%%%%%%%%%%   path: examples\SVAR   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help examples\SVAR\SvarTutorial">examples\SVAR\SvarTutorial</a>                   - % housekeeping
%   <a href="matlab:help examples\SVAR\blanchard_perotti_2002">examples\SVAR\blanchard_perotti_2002</a>         - % housekeeping
%   <a href="matlab:help examples\SVAR\blanchard_perotti_restrictions">examples\SVAR\blanchard_perotti_restrictions</a> - a_g=param(1); % -inf inf
%   <a href="matlab:help examples\SVAR\mertens_ravn_data">examples\SVAR\mertens_ravn_data</a>              -  used in papers:
%   <a href="matlab:help examples\SVAR\peersman_data">examples\SVAR\peersman_data</a>                  - source: http://www.cambridge.org/features/econmodelling/download/MATLAB.zip
