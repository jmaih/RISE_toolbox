%%%%%%%%%%%%%%%%%%%%   path: classes\+obsolete\@sadiff   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+obsolete\@sadiff\char">classes\+obsolete\@sadiff\char</a>             - % search for 0 instead
%   <a href="matlab:help classes\+obsolete\@sadiff\diff">classes\+obsolete\@sadiff\diff</a>             - check that I do not need to output the object thanks to the
%   <a href="matlab:help classes\+obsolete\@sadiff\differentiate">classes\+obsolete\@sadiff\differentiate</a>    - this function
%   <a href="matlab:help classes\+obsolete\@sadiff\hessian">classes\+obsolete\@sadiff\hessian</a>          - build wrt right here so that things don't get confused with the ordering
%   <a href="matlab:help classes\+obsolete\@sadiff\jacobian">classes\+obsolete\@sadiff\jacobian</a>         - objectives is a function handle or an array of function handles
%   <a href="matlab:help classes\+obsolete\@sadiff\neat">classes\+obsolete\@sadiff\neat</a>             - str=[func,'(',varargin{:},')'];
%   <a href="matlab:help classes\+obsolete\@sadiff\print">classes\+obsolete\@sadiff\print</a>            - remove unused definitions
%   <a href="matlab:help classes\+obsolete\@sadiff\sadiff">classes\+obsolete\@sadiff\sadiff</a>           - lassdef sadiff % < handle
%   <a href="matlab:help classes\+obsolete\@sadiff\sadiff_test_____">classes\+obsolete\@sadiff\sadiff_test_____</a> - % choose level
%   <a href="matlab:help classes\+obsolete\@sadiff\setup">classes\+obsolete\@sadiff\setup</a>            - objectives is a function handle or an array of function handles
