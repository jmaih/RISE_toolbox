%%%%%%%%%%%%%%%%%%%%   path: classes\+obsolete\@sadiff\private   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+obsolete\@sadiff\private\create_handle">classes\+obsolete\@sadiff\private\create_handle</a> - ndex=sprintf('%0.10g',operCount);
%   <a href="matlab:help classes\+obsolete\@sadiff\private\update_line">classes\+obsolete\@sadiff\private\update_line</a>   - f any(isletter(item))||strncmp(handle,indx,4) % do not waste time writing constant
