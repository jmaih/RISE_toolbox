%%%%%%%%%%%%%%%%%%%%   path: classes\+obsolete\@rise_anonymous   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+obsolete\@rise_anonymous\rise_anonymous">classes\+obsolete\@rise_anonymous\rise_anonymous</a> - % it is assumed that all objects in the vector share the same
