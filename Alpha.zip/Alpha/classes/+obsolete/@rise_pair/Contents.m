%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_pair   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_pair\rise_pair">classes\@rise_pair\rise_pair</a> - iter=0 % actual size
