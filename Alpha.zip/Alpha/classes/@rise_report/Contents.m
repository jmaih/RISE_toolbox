%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_report   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_report\rise_report">classes\@rise_report\rise_report</a> - % add some space between records for lisibility and for
