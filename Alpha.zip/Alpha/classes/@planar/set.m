function obj=set(obj,prop,value)

obj.(prop)=value;

end