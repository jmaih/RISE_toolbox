function val=get(obj,prop)
val=obj.(prop);