%%%%%%%%%%%%%%%%%%%%   path: classes\@rise_nad   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\@rise_nad\rise_nad">classes\@rise_nad\rise_nad</a> - % numerical automatic differentiation
