%%%%%%%%%%%%%%%%%%%%   path: classes\+distributions\+unfinished   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+distributions\+unfinished\dirichlet">classes\+distributions\+unfinished\dirichlet</a>           - % one dirichlet at a time
%   <a href="matlab:help classes\+distributions\+unfinished\mv_normal">classes\+distributions\+unfinished\mv_normal</a>           - C=b; % assume this is the cholesky...
%   <a href="matlab:help classes\+distributions\+unfinished\truncated_mv_normal">classes\+distributions\+unfinished\truncated_mv_normal</a> - references:
