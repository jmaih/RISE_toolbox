%%%%%%%%%%%%%%%%%%%%   path: classes\+msre_solvers\private   %%%%%%%%%%%%%%%%%%%%
%
%   <a href="matlab:help classes\+msre_solvers\private\A_times_X">classes\+msre_solvers\private\A_times_X</a> - computes A*X assuming the zero columns of A are deleted. the nonzero
%   <a href="matlab:help classes\+msre_solvers\private\X_times_A">classes\+msre_solvers\private\X_times_A</a> - computes X*A assuming the zero columns of A are deleted. the nonzero
